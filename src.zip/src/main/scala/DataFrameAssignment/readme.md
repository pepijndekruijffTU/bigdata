# Spark Dataframes (DF)

In the Spark DF assignments you will focus on the basics of Spark DFs. It is recommended
to read the Spark [documentation](https://spark.apache.org/docs/latest/api/scala/index.html),
as TAs require you to do your own research before asking questions.
